# ~/chef-repo/cookbooks/mychef-client/recipes/metadata.rb

name 'mychef-client'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'all_rights'
description 'Installs/Configures mychef-client'
long_description 'Installs/Configures mychef-client'
version '0.1.0'

depends 'chef-client', '= 7.0.2'