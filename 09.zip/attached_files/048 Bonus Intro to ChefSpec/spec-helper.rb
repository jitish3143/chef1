# ~/cookbooks/apache/spec/spec_helper.rb

require 'chefspec'
require 'chefspec/berkshelf'

ChefSpec::Coverage.start!