# chef-repo/cookbooks/myhaproxy/metadata.rb

name 'myhaproxy'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'all_rights'
description 'Installs/Configures myhaproxy'
long_description 'Installs/Configures myhaproxy'
version '1.0.1'

depends 'haproxy', '= 2.0.0'