name 'production'
description 'where production code is run'

cookbook 'apache', '= 0.2.1'
cookbook 'myhaproxy', '= 1.0.0'