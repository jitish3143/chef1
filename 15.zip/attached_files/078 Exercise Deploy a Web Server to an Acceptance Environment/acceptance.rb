name 'acceptance'
description 'where application code is tested'

# no cookbook restrictions