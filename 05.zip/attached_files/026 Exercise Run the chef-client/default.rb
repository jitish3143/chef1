# ~/cookbooks/apache/recipes/default.rb

include_recipe 'apache::server'
