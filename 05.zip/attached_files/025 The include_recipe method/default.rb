# ~/cookbooks/workstation/recipes/default.rb

include_recipe 'workstation::setup'