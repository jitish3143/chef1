name 'load-balancer'
description 'load balancer role'
run_list 'recipe[myhaproxy]'