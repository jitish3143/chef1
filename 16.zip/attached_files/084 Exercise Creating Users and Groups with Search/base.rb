name 'base'
description 'Base Role for all Servers'
run_list 'recipe[myusers]'