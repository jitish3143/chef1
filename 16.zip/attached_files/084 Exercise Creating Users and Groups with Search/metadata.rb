# chef-repo/cookbooks/myusers/metadata.rb

name 'myusers'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'all_rights'
description 'Installs/Configures myusers'
long_description 'Installs/Configures myusers'
version '0.2.0'